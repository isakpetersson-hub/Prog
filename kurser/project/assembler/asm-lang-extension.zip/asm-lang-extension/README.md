# Custom ASM Syntax Highlighting

Syntax highlighting for a custom assembly language.

## Features

Colors are applied to:
- **Instructions** — `load_pm`, `add`, `bra`, `halt`, etc.
- **Addressing modes** — `dir`, `ime`, `indp`, `indd`, `idx`
- **Registers** — `GR0` through `GR15`
- **Labels** — `@label` definitions and references
- **Numbers** — decimal and hex literals
- **Comments** — lines starting with or including `#`

## File Extensions

Files ending in `.asm` or `.s` will automatically use this syntax.

## Installation

See INSTALL.md for setup instructions.
