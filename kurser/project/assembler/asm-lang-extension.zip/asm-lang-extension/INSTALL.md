# Installation Instructions

1. Copy the `custom-asm-syntax` folder to your VS Code extensions directory:

   - **Windows**: `C:\Users\<you>\.vscode\extensions\custom-asm-syntax`
   - **macOS**: `~/.vscode/extensions/custom-asm-syntax`
   - **Linux**: `~/.vscode/extensions/custom-asm-syntax`

2. Restart VS Code.

3. Open a `.asm` or `.s` file — colors should appear automatically.

   If they don't, click the language name in the bottom-right corner of VS Code
   and select **"Custom ASM"** from the list.

